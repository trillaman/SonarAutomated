<?php

// Make sure the file is not directly accessible.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'We\'re sorry, but you can not directly access this file.' );
}

?>

<div class="health-check-modal" data-modal-action="" data-parent-field="">
	<div class="modal-content">
		<span class="modal-close">&times;</span>
		<div id="dynamic-content">
			&nbsp;
		</div>
	</div>
</div>
